//
//  MainCollectionViewCell.m
//  BabyKnow
//
//  Created by user on 16/3/23.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import "MainCollectionViewCell.h"
#import "Public.h"
@implementation MainCollectionViewCell


- (void)awakeFromNib {

    self.itemTableView.backgroundColor = RGBA(0, 0, 0, 0);
    self.itemTableView.delegate=self;
    self.itemTableView.dataSource=self;
    self.itemTableView.contentInset =UIEdgeInsetsMake(Head_Height, 0, 0, 0);
    
    }


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 30;
}

- (void)setContentIndex:(NSInteger)index
{
    self.index =index;
    [self.itemTableView reloadData];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *identfire = @"cellId";
    
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:identfire];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identfire];
    }
    cell.backgroundColor =RGB(246, 246, 246);
    
    cell.textLabel.text = [NSString stringWithFormat:@"--------------这是第%ld天的内容--------------",(long)self.index];
    
    return cell;
}

#pragma mark UIScrollViewDelegate
// 触摸屏幕来滚动画面还是其他的方法使得画面滚动，皆触发该函数
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
   [self.delegate tableView:(UITableView *)scrollView DrawWithFrame:scrollView.contentOffset.y actionType:0]; // 偏移的y值
    
}


// 触摸屏幕并拖拽画面，再松开，最后停止时，触发该函数
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    
     [self.delegate tableView:(UITableView *)scrollView DrawWithFrame:scrollView.contentOffset.y actionType:1];
}

@end
