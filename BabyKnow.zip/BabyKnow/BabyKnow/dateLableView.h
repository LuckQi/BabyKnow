//
//  dateLableView.h
//  BabyKnow
//
//  Created by user on 16/3/24.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol dateViewDelegate <NSObject>


-(void)didClicksegmentedControlAction:(NSInteger)tag;

@end

@interface dateLableView : UIView

- (IBAction)dateClick:(UIButton *)sender;


@property (assign, nonatomic) id delegate;

@end
