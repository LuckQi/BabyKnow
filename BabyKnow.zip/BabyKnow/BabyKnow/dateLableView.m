//
//  dateLableView.m
//  BabyKnow
//
//  Created by user on 16/3/24.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import "dateLableView.h"

@interface dateLableView ()
{
    UIButton *_selectButton;
}

@end

@implementation dateLableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self =[[[NSBundle mainBundle]loadNibNamed:@"dateLableView" owner:nil options:nil] firstObject];
        
        self.frame =frame;
        
        UIButton *btn= (UIButton *)[self viewWithTag:100];
        [self dateClick:btn];
    }
    return self;
}

- (IBAction)dateClick:(UIButton *)sender {
    
    _selectButton.selected = NO;
    
    sender.selected =YES;
    
    _selectButton = sender;
    
    [self.delegate didClicksegmentedControlAction:sender.tag];
}


@end
