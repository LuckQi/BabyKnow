//
//  AppDelegate.h
//  BabyKnow
//
//  Created by user on 16/3/23.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

