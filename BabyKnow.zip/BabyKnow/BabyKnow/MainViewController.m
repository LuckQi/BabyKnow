//
//  MainViewController.m
//  BabyKnow
//
//  Created by user on 16/3/23.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import "MainViewController.h"
#import "MainCollectionViewCell.h"
#import "Public.h"
#import "dateLableView.h"

static NSString *cellIdentifier0 = @"cellIdentifier0";
static NSString *cellIdentifier1 = @"cellIdentifier1";
static NSString *cellIdentifier2 = @"cellIdentifier2";
static NSString *cellIdentifier3 = @"cellIdentifier3";
static NSString *cellIdentifier4 = @"cellIdentifier4";
static NSString *cellIdentifier5 = @"cellIdentifier5";
static NSString *cellIdentifier6 = @"cellIdentifier6";


@interface MainViewController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout,MainCollectionViewCellDelegate>  {
    
    UIImageView *_backgroungView;
    
    UICollectionView *_collectionView;
    
    dateLableView *_dateView;
    
    UIButton *_selectButton;
}

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initCollectView];
    
    [self initBackgroundView];
    
    [self initDateSegmented];
    
   
    
}

- (void)initBackgroundView
{
    _backgroungView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screen_width, Head_Height)];
    
    _backgroungView.image =[UIImage imageNamed:@"test.jpg"];
    
    [self.view addSubview:_backgroungView];
    
    
}

- (void)initDateSegmented
{

    _dateView =[[dateLableView alloc]initWithFrame:CGRectMake(15, Head_Height-Dateview_Height, screen_width-30, Dateview_Height)];
    
    _dateView.delegate = self;
    
    [self.view addSubview:_dateView];

}

- (void)initCollectView
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    // 设置滚动的方向
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    // 清空行距
    layout.minimumLineSpacing = 0;
    //item大小
    layout.itemSize =[UIScreen mainScreen].bounds.size;

    
    _collectionView = [[UICollectionView alloc] initWithFrame:self.view.frame collectionViewLayout:layout];
    _collectionView.pagingEnabled = YES;
    _collectionView.bounces = NO;
    _collectionView.showsHorizontalScrollIndicator = NO;
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.backgroundColor =RGBA(0, 0, 0, 0);
    
    UINib *cellNib=[UINib nibWithNibName:@"MainCollectionViewCell" bundle:nil];
    
    for (int i=0; i<7; i++) {
        
        [_collectionView  registerNib:cellNib forCellWithReuseIdentifier:[NSString stringWithFormat:@"cellIdentfier%d",i]];
    }
    
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [self.view addSubview:_collectionView];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 7;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MainCollectionViewCell *cell =[collectionView dequeueReusableCellWithReuseIdentifier:[NSString stringWithFormat:@"cellIdentfier%ld",indexPath.item] forIndexPath:indexPath];
    
    if (cell.isUp) {
        
        [self.view bringSubviewToFront:_collectionView];
    }

    [cell setContentIndex:indexPath.item];
    cell.delegate = self;
    
    return cell;
}


-(void)tableView:(UITableView *)sender DrawWithFrame:(CGFloat)offy actionType:(int)type
{
    NSIndexPath *indexpath = [NSIndexPath indexPathForItem:_collectionView.contentOffset.x/screen_width inSection:0 ];
    
    MainCollectionViewCell *cell = (MainCollectionViewCell *)[_collectionView cellForItemAtIndexPath:indexpath];
    
    if (type ==0) {
        
        if (offy <0) {
            
            if (fabs(offy) >= Head_Height) {
                
                CGRect bgframe =_backgroungView.frame;
                CGRect seframe =_dateView.frame;
                
                bgframe.size.height = fabs(offy);
                seframe.origin.y =fabs(offy)-Dateview_Height;
                
                _backgroungView.frame =bgframe;
                _dateView.frame =seframe;
                [self.view sendSubviewToBack:_collectionView];
                
            }
            else {
                
                [self.view bringSubviewToFront:_collectionView];
                cell.isUp=YES;
                _backgroungView.frame =CGRectMake(0, 0, screen_width, Head_Height);
                _dateView.frame =CGRectMake(15, Head_Height-Dateview_Height, screen_width-30, Dateview_Height);
                
            }
            
        }
        
    }
    if (type == 1) {
        
        if (offy >= -Head_Height && offy <= -(Head_Height-Dateview_Height) ) {  //滑动没有超过日期部分，自动跳回
            
            [sender setContentOffset:CGPointMake(0, -Head_Height) animated:YES];

        }
    }
        
    
    
}

// 滚动停止时，触发该函数
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    NSIndexPath *indexpath = [NSIndexPath indexPathForItem:scrollView.contentOffset.x/screen_width inSection:0 ];
    
    MainCollectionViewCell *cell = (MainCollectionViewCell *)[_collectionView cellForItemAtIndexPath:indexpath];
    
    
    UIButton *selectBtn = (UIButton *)[_dateView viewWithTag:scrollView.contentOffset.x/screen_width+100];
    
    [_dateView dateClick:selectBtn];
    
    if (cell.itemTableView.contentOffset.y == -Head_Height) {
    
        [self.view sendSubviewToBack:_collectionView];
        
    }

}


-(void)didClicksegmentedControlAction:(NSInteger)tag
{
    
    [_collectionView setContentOffset:CGPointMake((tag-100)*screen_width, 0) animated:NO];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
