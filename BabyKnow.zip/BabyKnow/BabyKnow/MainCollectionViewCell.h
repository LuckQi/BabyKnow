//
//  MainCollectionViewCell.h
//  BabyKnow
//
//  Created by user on 16/3/23.
//  Copyright © 2016年 BoCo. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MainCollectionViewCellDelegate <NSObject>

- (void)tableView:(UITableView *)sender DrawWithFrame:(CGFloat)offy actionType:(int)type;
/**
 *  type 0: 滑动过程中
    type 1: 滑动停止手指离开 
 */

@end

@interface MainCollectionViewCell : UICollectionViewCell  <UITableViewDataSource, UITableViewDelegate,UIScrollViewDelegate>

- (void)setContentIndex:(NSInteger)index;

@property (strong, nonatomic) IBOutlet UITableView *itemTableView;

@property (assign, nonatomic) id delegate;

@property (assign, nonatomic) NSInteger index;

@property (assign, nonatomic) BOOL isUp; //记录tableview是否已拖动，显示式保持原位

@end
